---
title: Clipboard heart
categories:
  - Real world
tags:
  - copy
  - paste
---
