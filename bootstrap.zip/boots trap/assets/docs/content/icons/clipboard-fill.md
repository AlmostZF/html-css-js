---
title: Clipboard fill
categories:
  - Real world
tags:
  - copy
  - paste
---
